var APP_DATA = {
  "scenes": [
    {
      "id": "0-timothy-oldfield-luufnhochru-unsplash",
      "name": "timothy-oldfield-luufnHoChRU-unsplash",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1344,
      "initialViewParameters": {
        "yaw": -0.4564523119275261,
        "pitch": 0.04572523563019004,
        "fov": 1.5070412331994232
      },
      "linkHotspots": [
        {
          "yaw": -1.0596711878440601,
          "pitch": -0.2151279560519388,
          "rotation": 0,
          "target": "1-jose-g-ortega-castro-pypkpbbcnfw-unsplash"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-jose-g-ortega-castro-pypkpbbcnfw-unsplash",
      "name": "jose-g-ortega-castro-PYpkPbBCNFw-unsplash",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        },
        {
          "tileSize": 512,
          "size": 4096
        }
      ],
      "faceSize": 3000,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.20620967859870198,
          "pitch": 0.05728571397404458,
          "rotation": 0,
          "target": "0-timothy-oldfield-luufnhochru-unsplash"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.13687699273591392,
          "pitch": -0.1949752085598675,
          "title": "Title",
          "text": "Text"
        }
      ]
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
